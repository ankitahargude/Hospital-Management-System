CREATE DATABASE Hospital_Management_System;
CREATE TABLE Doctor (
    doctorid VARCHAR(5) PRIMARY KEY,
    doctorname VARCHAR(15) NOT NULL,
    dept VARCHAR(15) NOT NULL
);
CREATE TABLE Patient (
    Pid VARCHAR(5) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    age INT NOT NULL,
    weight INT NOT NULL,
    gender VARCHAR(10) NOT NULL,
    address VARCHAR(50) NOT NULL,
    phoneno INT NOT NULL,
    disease VARCHAR(20) NOT NULL,
    doctorid VARCHAR(5) NOT NULL,
    FOREIGN KEY (doctorid) REFERENCES Doctor(doctorid)
);
CREATE TABLE Lab (
    labno VARCHAR(5) PRIMARY KEY,
    pid VARCHAR(5) NOT NULL,
    weight INT NOT NULL,
    doctorid VARCHAR(5),
    date DATETIME NOT NULL,
    category VARCHAR(15) NOT NULL,
    patient_type VARCHAR(15) NOT NULL,
    amount INT NOT NULL,
    FOREIGN KEY (pid) REFERENCES Patient(Pid),
    FOREIGN KEY (doctorid) REFERENCES Doctor(doctorid)
);
CREATE TABLE Inpatient (
    pid VARCHAR(5) PRIMARY KEY,
    room_no VARCHAR(50) NOT NULL,
    date_of_adm DATETIME NOT NULL,
    date_of_dis DATETIME NOT NULL,
    advance INT NOT NULL,
    labno VARCHAR(5),
    FOREIGN KEY (labno) REFERENCES Lab(labno)
);
CREATE TABLE Outpatient (
    pid VARCHAR(5) PRIMARY KEY,
    date DATETIME NOT NULL,
    labno VARCHAR(5),
    FOREIGN KEY (labno) REFERENCES Lab(labno)
);
CREATE TABLE Room (
    room_no VARCHAR(50) PRIMARY KEY,
    room_type VARCHAR(10) NOT NULL,
    status VARCHAR(10) NOT NULL
);
CREATE TABLE Bill (
    bill_no VARCHAR(50) PRIMARY KEY,
    pid VARCHAR(5),
    FOREIGN KEY (pid) REFERENCES Patient(Pid),
    patient_type VARCHAR(10),
    doctor_charge INT NOT NULL,
    medicine_charge INT NOT NULL,
    room_charge INT NOT NULL,
    oprtn_charge INT,
    no_of_days INT,
    nursing_charge INT,
    advance INT,
    health_card VARCHAR(50),
    lab_charge INT,
    bill INT NOT NULL
);
SELECT * FROM Patient;
SELECT * FROM Doctor;
SELECT * FROM Inpatient;
SELECT * FROM Outpatient;
SELECT * FROM Lab;
SELECT * FROM Room;
SELECT * FROM Bill;
